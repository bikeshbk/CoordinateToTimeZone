create function check_loop_in_predecessor(successor_id bigint, predecessor_id bigint)
  returns boolean
language plpgsql
as $$
DECLARE has_loop BOOLEAN;
					BEGIN
						   WITH RECURSIVE search_graph(project_task_id,predecessor_project_task_id, path, cycle) AS (
				
						        SELECT g.project_task_id,g.predecessor_project_task_id, ARRAY[g.project_task_id, g.predecessor_project_task_id], $2=ANY(ARRAY[g.project_task_id, g.predecessor_project_task_id])  FROM project_task_predecessor g where g.predecessor_project_task_id=$1 and status='ACTIVE'
				
						      UNION ALL
				
						        SELECT g.project_task_id,g.predecessor_project_task_id, path || g.project_task_id,
						          $2 = ANY(path || g.project_task_id)
						          
						        FROM project_task_predecessor g ,search_graph sg
						        where g.predecessor_project_task_id = sg.project_task_id and g.status='ACTIVE' AND NOT cycle
							)
							SELECT count(*) >0 INTO has_loop FROM search_graph where cycle=true;
						 RETURN has_loop;
					END;

$$;

alter function check_loop_in_predecessor(bigint, bigint)
  owner to ontarget;

